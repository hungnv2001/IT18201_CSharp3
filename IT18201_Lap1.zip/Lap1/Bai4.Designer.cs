﻿namespace Lap1
{
    partial class Bai4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bt_Exit = new System.Windows.Forms.Button();
            this.bt_Total = new System.Windows.Forms.Button();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.check_Cao = new System.Windows.Forms.CheckBox();
            this.check_Tay = new System.Windows.Forms.CheckBox();
            this.Check_Chup = new System.Windows.Forms.CheckBox();
            this.gia1 = new System.Windows.Forms.Label();
            this.gia2 = new System.Windows.Forms.Label();
            this.gia3 = new System.Windows.Forms.Label();
            this.gia4 = new System.Windows.Forms.Label();
            this.num_Tram = new System.Windows.Forms.NumericUpDown();
            this.list_KH = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.num_Tram)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(79, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dental Payment Form";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên khách hàng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 313);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Trám răng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(146, 378);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total";
            // 
            // bt_Exit
            // 
            this.bt_Exit.Location = new System.Drawing.Point(63, 444);
            this.bt_Exit.Name = "bt_Exit";
            this.bt_Exit.Size = new System.Drawing.Size(94, 29);
            this.bt_Exit.TabIndex = 4;
            this.bt_Exit.Text = "Thoát";
            this.bt_Exit.UseVisualStyleBackColor = true;
            // 
            // bt_Total
            // 
            this.bt_Total.Location = new System.Drawing.Point(286, 450);
            this.bt_Total.Name = "bt_Total";
            this.bt_Total.Size = new System.Drawing.Size(94, 29);
            this.bt_Total.TabIndex = 5;
            this.bt_Total.Text = "Tính tiền";
            this.bt_Total.UseVisualStyleBackColor = true;
            this.bt_Total.Click += new System.EventHandler(this.bt_Total_Click);
            // 
            // txt_name
            // 
            this.txt_name.ForeColor = System.Drawing.Color.Red;
            this.txt_name.Location = new System.Drawing.Point(184, 120);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(199, 27);
            this.txt_name.TabIndex = 6;
            // 
            // txt_total
            // 
            this.txt_total.BackColor = System.Drawing.SystemColors.Info;
            this.txt_total.Enabled = false;
            this.txt_total.Location = new System.Drawing.Point(247, 375);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(106, 27);
            this.txt_total.TabIndex = 7;
            // 
            // check_Cao
            // 
            this.check_Cao.AutoSize = true;
            this.check_Cao.Location = new System.Drawing.Point(32, 181);
            this.check_Cao.Name = "check_Cao";
            this.check_Cao.Size = new System.Drawing.Size(81, 24);
            this.check_Cao.TabIndex = 8;
            this.check_Cao.Text = "Cạo vôi";
            this.check_Cao.UseVisualStyleBackColor = true;
            // 
            // check_Tay
            // 
            this.check_Tay.AutoSize = true;
            this.check_Tay.Location = new System.Drawing.Point(32, 225);
            this.check_Tay.Name = "check_Tay";
            this.check_Tay.Size = new System.Drawing.Size(93, 24);
            this.check_Tay.TabIndex = 9;
            this.check_Tay.Text = "Tẩy trắng";
            this.check_Tay.UseVisualStyleBackColor = true;
            // 
            // Check_Chup
            // 
            this.Check_Chup.AutoSize = true;
            this.Check_Chup.Location = new System.Drawing.Point(32, 269);
            this.Check_Chup.Name = "Check_Chup";
            this.Check_Chup.Size = new System.Drawing.Size(131, 24);
            this.Check_Chup.TabIndex = 10;
            this.Check_Chup.Text = "Chụp hình răng";
            this.Check_Chup.UseVisualStyleBackColor = true;
            // 
            // gia1
            // 
            this.gia1.AutoSize = true;
            this.gia1.Location = new System.Drawing.Point(299, 181);
            this.gia1.Name = "gia1";
            this.gia1.Size = new System.Drawing.Size(68, 20);
            this.gia1.TabIndex = 11;
            this.gia1.Text = "$100.000";
            // 
            // gia2
            // 
            this.gia2.AutoSize = true;
            this.gia2.Location = new System.Drawing.Point(288, 229);
            this.gia2.Name = "gia2";
            this.gia2.Size = new System.Drawing.Size(79, 20);
            this.gia2.TabIndex = 12;
            this.gia2.Text = "$1.200.000";
            // 
            // gia3
            // 
            this.gia3.AutoSize = true;
            this.gia3.Location = new System.Drawing.Point(299, 273);
            this.gia3.Name = "gia3";
            this.gia3.Size = new System.Drawing.Size(68, 20);
            this.gia3.TabIndex = 13;
            this.gia3.Text = "$200.000";
            // 
            // gia4
            // 
            this.gia4.AutoSize = true;
            this.gia4.Location = new System.Drawing.Point(282, 313);
            this.gia4.Name = "gia4";
            this.gia4.Size = new System.Drawing.Size(85, 20);
            this.gia4.TabIndex = 14;
            this.gia4.Text = "$80.000/cái";
            // 
            // num_Tram
            // 
            this.num_Tram.Location = new System.Drawing.Point(126, 313);
            this.num_Tram.Name = "num_Tram";
            this.num_Tram.Size = new System.Drawing.Size(62, 27);
            this.num_Tram.TabIndex = 15;
            // 
            // list_KH
            // 
            this.list_KH.FormattingEnabled = true;
            this.list_KH.ItemHeight = 20;
            this.list_KH.Location = new System.Drawing.Point(425, 181);
            this.list_KH.Name = "list_KH";
            this.list_KH.Size = new System.Drawing.Size(255, 64);
            this.list_KH.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(474, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "danh sách khách hàng";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(486, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 54);
            this.button1.TabIndex = 18;
            this.button1.Text = "Lấy danh sách từ file";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Bai4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(727, 624);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.list_KH);
            this.Controls.Add(this.num_Tram);
            this.Controls.Add(this.gia4);
            this.Controls.Add(this.gia3);
            this.Controls.Add(this.gia2);
            this.Controls.Add(this.gia1);
            this.Controls.Add(this.Check_Chup);
            this.Controls.Add(this.check_Tay);
            this.Controls.Add(this.check_Cao);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.bt_Total);
            this.Controls.Add(this.bt_Exit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Bai4";
            this.Text = "Bai4";
            ((System.ComponentModel.ISupportInitialize)(this.num_Tram)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button bt_Exit;
        private Button bt_Total;
        private TextBox txt_name;
        private TextBox txt_total;
        private CheckBox check_Cao;
        private CheckBox check_Tay;
        private CheckBox Check_Chup;
        private Label gia1;
        private Label gia2;
        private Label gia3;
        private Label gia4;
        private NumericUpDown num_Tram;
        private ListBox list_KH;
        private Label label9;
        private Button button1;
    }
}